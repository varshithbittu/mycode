<?php

       $host='details.coeveysrjzjv.us-east-2.rds.amazonaws.com';
       $user='varshith';
       $pass='varshith123';
       $db_name='details';

        $conn = new mysqli($host,$user,$pass,$db_name);
        if($conn->connect_error){
		die('Connection Failed : '. $conn->connect_error);
}
?>